<?php


return [

    'talkwithme'=>'talkwithme',
    '2'=>'Online consultation',
    '3'=>'on phone consultancy',
    '5'=>'In-person counseling',
    '6'=>'business Coaching',

    '7'=>'read and know',
    '8'=>'about kajyoutub',
    '9'=>'news and articles room',
    '10'=>'Recruitment',
    '11'=>'contact with kajyoutub',
    '12'=>'Terms and Conditions',

    'address'=>'Anzali Free Zone',
    'email'=>'info@kajyoutube.com',
    'phone'=>'021-41256226',
    'Follow'=>'Follow us' 
    


];